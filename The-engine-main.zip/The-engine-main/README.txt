This project is designed as a solution to workflow automation, content repurposing and email outreach
